/** An HTTP+HTTP/2 client for Android and Java applications. */
@okhttp3.internal.annotations.EverythingIsNonNull
package okhttp3;
